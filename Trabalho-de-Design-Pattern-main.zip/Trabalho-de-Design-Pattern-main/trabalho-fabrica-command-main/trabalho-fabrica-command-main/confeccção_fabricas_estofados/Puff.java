public class Puff implements Estofado {
    @Override
    public void confecionar() {
        System.out.println("Fabricando um Puff...");
    }
}
