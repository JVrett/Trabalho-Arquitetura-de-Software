public class Sofa implements Estofado {
    @Override
    public void confecionar() {
        System.out.println("Fabricando um Sofá...");
    }
}
