public class Cadeira implements Estofado {
    @Override
    public void confecionar() {
        System.out.println("Fabricando uma Cadeira...");
    }
}
