public interface Estofado {
    void confecionar();
}
