public interface Comando {
    void executar();
}
git add .
